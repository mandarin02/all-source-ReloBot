#pragma once

namespace SDK
{
	namespace userinterface
	{
		namespace settings
		{



			bool FlameTurret;
			bool esp_bot = 1;
			bool esp_bottulel;
			bool esp_bot_healh;
			bool AutoTurret;
			bool BearTrap;
			bool GunTrap;
			bool Trap;

			bool Landmine;
		
			bool BaseOven;
			bool Scientist;
			bool HTNPlayer;




			float thick_bullet_value;








			bool TreeEntity;
			float smooth_value =3;
			int Beslee =2;
			int Randdelta =90;
			bool aimbot_smoothing;
			int bone_choice;
			 bool bESPEnabled;
			 int aim_Key;
			 bool bESPHead;
			 bool bESPEnemyOnly;
			 bool bESPLockedEnnemy;
			  bool bESPSnapline;
			  bool bESPHasArmor;
			  bool bESP2DBox;
			  bool bESP3DBox;
			  bool bESPHealth;
			  bool bESPHealthText;
			  bool bESPName;
			  bool bESPDistance;
			  bool bESPFlashed;
			  bool bESPHostage;
			  bool bESPTeamOnly;
			  bool bESPSpotted;

			  bool bNoSmoke;
			  bool bNoEffects;
			  bool bGlaz;

			  float fGlaz1;
			  float fGlaz2;
			  float fGlaz3;

			  bool bESPTeam;
			  bool bESPEnemy;

			  bool bGadget;
			  bool bGadgetDebug;

			  int AimbotKey;
			  int Possaim;

			
			  bool bUnload;

			  bool bVisualsCrosshair;
			  bool bVisualsFPS;

			  bool bAccuracyNoSpread;
			   bool bAccuracyNoRecoil;

			  bool bAccuracyAimbot;
			  bool bAccuracyAimShowFOV;
			  bool bAimLock;
			  bool bAccuracyTrigger;

			  bool bTeleport;

			  bool Menu;

			  int aimbotTarget;
			  int teleportTarget;

			  int aimFov;
			  int aimDist;
			  int aimSmooth;
			bool aimbot_bullet_drop;
			bool aimbot;
			bool esp_inventory =1;
			bool esp_inventory1 =0;
			bool esp_player_sleeping=1;
			bool crosshair=1;
			bool DrawCircle=1;
			bool show_fov;
			float fov_value = 50;
			float bounce1 = 1;
			float bounce2 = 1;
			float bounce3 = 1;
			 

			bool esp_tab;
			bool esp =0;
			bool esp1 ;
			bool esp2 ;
			bool esp33 ;
			bool workbench;
			bool workbench1;
			bool workbench2;
			bool workbench3;
			bool world;
			bool world2;
			bool worldpickup;
			bool worldpickup2;
			bool worldpickup1;
			bool worldbox;
			bool backpack;
			bool berry;
			bool esp4 ;
			bool EggHuntEvent=1;
			bool EggHuntEvent1=0;
			bool EggHuntEvent2=0;
			bool CollectableEasterEgg;
			bool CollectableEasterEggline;
			bool RustigeEgg;
			bool CommunityEntity;
			bool DroppedItemContainer;
			bool esp_Stash3;
			bool esp_apc;
			bool esp_apc1;
			bool esp_Stash2;
			bool esp_Stash1;
			bool esp_ResourceEntity;
			bool esp_others;
			bool esp_Gun;
			bool OreHotSpot;
			bool TreeManager;
			bool BaseMelee;
			bool BaseProjectile;
			bool BasePlayer;
			bool Container;






			bool	FreeableLootContainer;
			bool Recycler;
			bool CollectibleEntity;
			
			bool hemp_coletavel;
			bool mushrooms_coletavel;
			bool metal_coletavel;
			bool sulfur_coletavel;
			bool stone_coletavel;
			bool food;
			bool wood_coletavel;
			bool _coletavel; 

			bool JunkPileWater;
			bool VendingMachineMapMarker;
			bool Planner;
			bool HotSpot;
			bool ProjectileWeaponMod;
			bool ScientistNPC;
			bool BaseChair;
			bool LightListener;
			bool ItemPickup;
			bool minicopert=1;
			bool Patrol=0;

			bool Stash=1;
			bool Stash1=0;
			bool BaseNPC;
			bool HackableLockedCrate;
			bool keys;
			bool esp_SuplyDrop=1;
			bool esp_SuplyDropLine;
			bool esp_player =1;
			bool esp_NickName ;
			bool esp_player_lines ;
			bool esp_player_lines_sleepers;
			bool esp_player_Debug;
			bool esp_player_box;
			bool esp_player_Box_Sleeping;
			bool esp_player_skeleton =1;
			bool esp_player_visible = 1;
			bool sulfur;
			bool metal;
			bool stone;
			bool sulfurline;
			bool metalline;
			bool stoneline;
			bool esp_rock=1;
			bool esp_oreOnly;
			bool esp_chicken;
			bool esp_bear;
			bool esp_wolf;
			bool esp_deer;
			bool GrenadeWeapon;
			bool TorchWeapon;
			bool ExcavatorArm;
			bool esp_boxElite;
			bool esp_dielse;
			bool esp_Stash;
			bool esp_Stash_red;
			bool esp_Stash_green;
			bool esp_Stash_blue;
			bool cloth;
			bool drop_backpack=1;
			bool corpse=1;
			bool bradley_crate;
			bool BradleyAPCs;

			bool crate_mine;
			bool crate_normal;
			bool crate_tools;		
			bool crate_basic;
			bool esp_loot_container;
			bool esp_Projectile;
			bool esp_boar;
			bool esp_horse;
			bool esp_vehicles;
			bool TC;
			bool esp_max ;
			float font_size = 16.f;
			float esp_max_distance =1000.f;
			bool aim_tab;
			bool recoil_modify;
			float recoil_value ;
			float thick_bulletf;
			bool sway_modify;
			float sway_value ;
			bool debug_camera =0;
			bool debug_camera1 =0;
			bool debug_camera2 =0;
			bool debug_camera3 =0;
			bool debug_camera4 =0;
			bool debug_camera5 =0;
			bool debug_camera6 =0;

			bool debug_camera21 = 0;
			bool debug_camera22 = 0;
			bool debug_camera23 = 0;
			bool debug_camera24 = 0;
			bool debug_camera25 = 0;

			bool climb_walls;
			bool climb_walls1;
			bool maxVelocity;
			float maxVelocityf;
			bool high_step;
			bool no_fall;
			bool no_fall1;
			bool no_fall2;
			bool no_gravity;
			bool auto_weapons;
			bool modify_cave_brightness;
			bool modify_sky_hour;

			float hour_sky;
			bool third_person;
			bool eggvisionbool;
			bool fast_bullet;
			bool fast_bullet2;
			bool UseSelf;
			bool thick_bullet =false ;
			bool thick_bullet1 =false;
			bool thick_bullet2 =false;
			bool Penetration;
			bool Penetration1;
			bool no_range;
			bool no_reloadEndDuration;
			bool mod_projectileVelocityScale;
			float mod_projectileVelocityScalef;
			bool Noise;
			bool instant_eoka;
			bool no_spread;
			float max_melee_distance;
			bool modify_max_melee_distance;
			bool no_spread2;
			float spread_value = 2.500;
			float egg_float ;
		}
	}
}